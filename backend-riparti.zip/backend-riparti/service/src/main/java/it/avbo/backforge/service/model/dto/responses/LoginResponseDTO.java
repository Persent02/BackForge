package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'oggetto JSON inviato al client in caso di procedura di login effettuata correttamente")
public class LoginResponseDTO {

    @Schema(description = "Il messaggio di servizio che indica lo stato dell'operazione", examples = "Login effettuato")
    private String message;

    @Schema(description = "Il token JWT creato per identificare l'utente")
    private String session_token;

    public LoginResponseDTO() {}

    public LoginResponseDTO(String message, String session_token) {
        this.message = message;
        this.session_token = session_token;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSession_token() {
        return session_token;
    }

    public void setSession_token(String session_token) {
        this.session_token = session_token;
    }
}
