package it.avbo.backforge.service.model.dto.requests;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "I dati che vengono inviati dall'utente quando vuole effettuare il login")
public class LoginRequest {

    @Schema(description = "L'email dell'utente", examples = "mattew.zawn@avbo.it")
    private String email;

    @Schema(description = "La password dell'utente", examples = "Password01")
    private String password;

    public LoginRequest() {}

    public LoginRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}