package it.avbo.backforge.service.control;

import it.avbo.backforge.service.dao.*;
import it.avbo.backforge.service.exceptions.*;
import it.avbo.backforge.service.model.dto.requests.CourseInputDataDTO;
import it.avbo.backforge.service.model.dto.responses.CourseListDTO;
import it.avbo.backforge.service.model.dto.requests.LessonRequiredDataDTO;
import it.avbo.backforge.service.model.dto.responses.SimpleLessonDTO;
import it.avbo.backforge.service.model.dto.SingleCourseDTO;
import it.avbo.backforge.service.model.jpa.*;
import it.avbo.backforge.service.security.CourseValidator;
import it.avbo.backforge.service.utility.DateConverter;
import it.avbo.backforge.service.utility.EmailService;
import it.avbo.backforge.service.utility.Formatter;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.sql.Date;
import java.util.List;

@ApplicationScoped
public class CourseService {

    @Inject
    private CourseDAO courseDAO;

    @Inject
    private LessonDAO lessonDAO;

    @Inject
    private CourseSpecializationsDAO courseSpecializationsDAO;

    @Inject
    private CourseYearsDAO courseYearsDAO;

    @Inject
    private SubscriptionDAO subscriptionDAO;

    @Inject
    private ParticipationDAO participationDAO;

    /**
     * Metodo del layer di Control dell'entità Course che ritorna al client la lista dei corsi in base al tipo di utente
     * @param email l'indirizzo email dell'utente fornito al momento dell'autenticazione
     * @return un oggetto CourseListDTO contenente la lista dei corsi
     * @throws DataNotValidException se durante il controllo del tipo di utente l'email non è ne @avbo.it ne @aldini.istruzioneer.it
     */
    public CourseListDTO getCoursesList(String email) throws DataNotValidException {

        //  Verifica se l'utente è Studente o Docente
        List<Course> courses;
        if(email.endsWith("@avbo.it")) { //docente
            courses = courseDAO.getCoursesByTeacherEmail(email);
        } else if (email.endsWith("@aldini.istruzioneer.it")) { //studente
            courses = courseDAO.getCoursesByStudentEmail(email);
        } else {
            throw new DataNotValidException("Invalid user email");
        }

        // Ritorna i corsi
        Course[] coursesArray = courses.toArray(new Course[0]);
        return new CourseListDTO("Richiesta elaborata con successo",coursesArray);
    }

    /**
     * Metodo del layer di Control per l'entità Course che si occupa di inserire all'interno del database i dati del corso inviati da un utente
     * @param request il body della richiesta
     * @param email il token di autenticazione dell'utente
     * @throws DataNotValidException Se durante il controllo dei dati qualche dato non rispetta i requisiti
     */
    public void createCourse(CourseInputDataDTO request, String email) throws DataNotValidException, NotAllowedException {

        //2. Controlli i dati inviati con la richiesta
        CourseValidator.validateCourseInputData(request);

        //3. Inserisci i dati relativi al corso dentro course
        Course course = new Course(
                request.getTitle(),
                request.getSubject(),
                request.getMin_participants(),
                request.getMax_participants(),
                request.getDescription(),
                email,
                "not activated",
                request.getType()
        );

        courseDAO.insertCourse(course);

        //4. Inserisci gli anni del corso dentro CourseYears
        String[] years = request.getYears();
        for (String year : years) {
            CourseYearsId id = new CourseYearsId(year, course.getId());
            CourseYears year_table_record = new CourseYears(id);

            courseYearsDAO.insertYear(year_table_record);
        }

        //5. Inserisci gli indirizzi del corso dentro CourseSpecialization
        String[] specializations = request.getSpecializations();
        for (String specialization : specializations) {
            CourseSpecializationsId id = new CourseSpecializationsId(specialization, course.getId());
            CourseSpecializations specialization_table_record = new CourseSpecializations(id);

            courseSpecializationsDAO.insertSpecialization(specialization_table_record);
        }

        //6. Inserisci le lezioni del corso dentro Lesson
        LessonRequiredDataDTO[] lessons = request.getLessons();
        for (LessonRequiredDataDTO lesson : lessons) {
            long date = DateConverter.convertDateToLong(lesson.getDate());
            System.out.println(date + "");
            int[] start_time = DateConverter.covertTimeToIntArray(lesson.getStart_time());
            int[] end_time = DateConverter.covertTimeToIntArray(lesson.getEnd_time());

            Lesson lesson_table_record = new Lesson(new Date(date), course.getId(), start_time[0], start_time[1], end_time[0], end_time[1]);
            lessonDAO.insertLesson(lesson_table_record);
        }
    }

    /**
     * Metodo del layer di Control per l'entità Course che si occupa di ritornare al client tutti i dati relativi a un corso
     * @param course_id l'id del corso di cui si vogliono avere tutti i dati
     * @return un oggetto SingleCourseResponse contenente tutte le informazioni del corso
     * @throws DataNotValidException se durante la validazione del codice del corso avviene un errore
     */
    public SingleCourseDTO getCourseData(int course_id) throws DataNotValidException {

        // 2. Controlli che l'id del corso non sia vuoto / dentro i parametri
        CourseValidator.validateId(course_id);
        SingleCourseDTO response = new SingleCourseDTO();

        // 3. Prendi tutte le info di quel corso da Course
        Course course_info  = courseDAO.getCourseById(course_id);

        response.setId(course_info.getId());
        response.setTitle(course_info.getTitle());
        response.setSubject(course_info.getSubject());
        response.setMin_participants(course_info.getNum_min());
        response.setMax_participants(course_info.getNum_max());
        response.setDesc(course_info.getDescription());
        response.setCreator_email(course_info.getTeacher_email());
        response.setStatus(course_info.getStatus());
        response.setType(course_info.getType());

        // 4. Prendi tutti gli anni e gli indirizzi da CourseYears e CourseSpecialization
        String[] years = courseYearsDAO.getYearsByCourseId(course_id).toArray(new String[0]);
        response.setYears(years);

        String[] specializations = courseSpecializationsDAO.getSpecializationsByCourseId(course_id).toArray(new String[0]);
        response.setSpecializations(specializations);

        // 5. Prendi tutte le iscrizioni da Subscription
        String[] subscribed = subscriptionDAO.getSubscribedByCourse(course_id).toArray(new String[0]);
        response.setParticipants(subscribed);

        // 6. Prendi tutte le lezioni da Lesson e per ogni lezione le partecipazioni da Participation
        List<Lesson> result = lessonDAO.getLessonsByCourse(course_id);
        List<SimpleLessonDTO> lessons = new java.util.ArrayList<>(List.of());

        for (Lesson lesson : result) {

            SimpleLessonDTO dto = new SimpleLessonDTO();
            dto.setDate(lesson.getDate().toString());
            dto.setStart_time(lesson.getStart_time());
            dto.setEnd_time(lesson.getEnd_time());

            String[] participants = participationDAO.getParticipantsByLesson(lesson.getId()).toArray(new String[0]);
            dto.setParticipants(participants);

            lessons.add(dto);
        }

        response.setLessons(lessons.toArray(new SimpleLessonDTO[0]));

        return response;
    }

    /**
     * Metodo del layer di control per l'entità Course che si occupa di settare lo stato di un corso ad attivo
     * @param course_id l'id del corso che si intende attivare
     * @throws ResourceNotFoundException se il corso specificato non viene trovato
     */
    public void activateCourse(int course_id) throws ResourceNotFoundException {

        //controllo esistenza corso
        Course selected_course = courseDAO.getCourseById(course_id);
        if (selected_course == null) {
            throw new ResourceNotFoundException("Course not found");
        }

        //controllo presenza minima studenti
        List<String> subscribeds =  subscriptionDAO.getSubscribedByCourse(selected_course.getId());
        if (subscribeds.size() < selected_course.getNum_min() || subscribeds.size() > selected_course.getNum_max()) {
            throw new NotAllowedException("Not allowed to activate course");
        }

        //set status corso a active
        courseDAO.activateCourse(course_id);

        for (String subscribed_email : subscribeds) {
            String message = getActivationMessage(subscribed_email, selected_course.getTeacher_email(), selected_course.getTitle());
            EmailService.sendEmail(subscribed_email, message, "Comunicazione RIPARTI | Un corso a cui sei iscritto è stato attivato");
        }

    }

    private String getActivationMessage(String student_email, String teacher_email, String course_title) {

        //ricavi nome e cognome di docente e studente
        String[] student_name_surname = Formatter.getNameAndSurnameFromEmail(student_email);
        String[] teacher_name_surname = Formatter.getNameAndSurnameFromEmail(teacher_email);

        return "Gentile studente " + student_name_surname[0] + " " + student_name_surname[1] + "\n\n Il team di riparti ti avvisa che il corso " + course_title + " del docente " + teacher_name_surname[0] + " " + teacher_name_surname[1] + " è stato attivato.\n Riparti";
    }

    /**
     * Metodo del layer di control per l'entità Course che si occupa di eliminare un corso
     * @param course_id l'id del corso che si intende eliminare
     * @throws ResourceNotFoundException se il corso specificato non viene trovato
     */
    public void deleteCourse(int course_id) throws ResourceNotFoundException {

        //ricerca corso e lezioni relative
        Course selected_course = courseDAO.getCourseById(course_id);
        if (selected_course == null) {
            throw new ResourceNotFoundException("Course not found");
        }

        //eliminazione partecipazioni, lezioni e iscrizioni al corso
        participationDAO.deleteParticipationsByCourse(course_id);
        lessonDAO.deleteLessonsByCourse(course_id);
        subscriptionDAO.deleteByCourseId(course_id);

        //eliminazione anni e specializzazioni corso
        List<String> course_years = courseYearsDAO.getYearsByCourseId(course_id);
        List<String> course_specs = courseSpecializationsDAO.getSpecializationsByCourseId(course_id);

        for (String course_year : course_years) {

            CourseYearsId yearId = new CourseYearsId();
            yearId.setCourse_id(course_id);
            yearId.setYear(course_year);

            CourseYears yearEntity = new CourseYears(yearId);
            courseYearsDAO.deleteYear(yearEntity);
        }

        for (String course_spec: course_specs) {

            CourseSpecializationsId specializationId = new CourseSpecializationsId();
            specializationId.setCourse_id(course_id);
            specializationId.setName(course_spec);

            CourseSpecializations specializationEntity = new CourseSpecializations(specializationId);
            courseSpecializationsDAO.deleteSpecialization(specializationEntity);
        }

        //eliminazione corso
        courseDAO.deleteCourseById(course_id);
    }
}

