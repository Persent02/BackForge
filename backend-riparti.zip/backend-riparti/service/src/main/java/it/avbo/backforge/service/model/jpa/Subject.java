package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.*;

@Entity
@Table(name = "Subject")
public class Subject {

    @EmbeddedId
    private SubjectId id;

    public Subject() {}

    public Subject(SubjectId id) {
        this.id = id;
    }

    public String getNome() {
        return id.getName();
    }

    public void setNome(String nome) {
        id.setName(nome);
    }

    public String getEmailProf() {
        return id.getTeacher_email();
    }

    public void setEmailProf(String email_prof) {
        id.setTeacher_email(email_prof);
    }
}