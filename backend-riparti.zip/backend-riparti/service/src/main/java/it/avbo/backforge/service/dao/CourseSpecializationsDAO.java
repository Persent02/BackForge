package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.CourseSpecializations;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface CourseSpecializationsDAO {

    void insertSpecialization(CourseSpecializations courseSpecialization);
    void deleteSpecialization(CourseSpecializations courseSpecialization);
    List<String> getSpecializationsByCourseId(int course_id);
}
