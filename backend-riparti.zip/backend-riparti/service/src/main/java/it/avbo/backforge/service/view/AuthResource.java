package it.avbo.backforge.service.view;

import it.avbo.backforge.service.control.AuthService;
import it.avbo.backforge.service.exceptions.AlreadyRegisteredException;
import it.avbo.backforge.service.exceptions.DataNotValidException;
import it.avbo.backforge.service.exceptions.UserNotFoundException;
import it.avbo.backforge.service.exceptions.WrongCredentialsException;
import it.avbo.backforge.service.model.dto.responses.BasicResponseDTO;
import it.avbo.backforge.service.model.dto.requests.LoginRequest;
import it.avbo.backforge.service.model.dto.responses.LoginResponseDTO;
import it.avbo.backforge.service.model.dto.requests.RegistrationRequest;
import jakarta.annotation.security.PermitAll;
import jakarta.ejb.Stateless;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;

import java.util.Optional;

@Path("/auth")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AuthResource {

    @Inject
    private AuthService authService;

    @POST
    @Path("/register")
    @Operation(summary = "elabora la richiesta di registrazione di un nuovo utente")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "201",
                    description = "Registrazione effettuata",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "409",
                    description = "Email già utilizzata per un altro utente",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "422",
                    description = "I dati non rispettano i controlli",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response register(
            @RequestBody(
                    description = "Dati utente da registrare",
                    content = @Content(schema = @Schema(implementation = RegistrationRequest.class)))
            RegistrationRequest registrationRequest
    ) {
        try {
            authService.userRegistration(registrationRequest);
        } catch (DataNotValidException dnve) {
            //per il futuro: aggiungi il logger
            return Response.status(422)
                    .entity(new BasicResponseDTO(dnve.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (AlreadyRegisteredException are) {
            //per il futuro: aggiungi il logger
            return Response.status(409)
                    .entity(new BasicResponseDTO("Email già utilizzata per un altro account"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            //per il futuro: aggiungi il logger
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(201)
                .entity(new BasicResponseDTO("Registrazione effettuata"))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

    @POST
    @Path("/login")
    @Operation(summary = "elabora la richiesta di login di un utente esistente")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Login effettuato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Credenziali non valide o utente non registrato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response login(
            @RequestBody(
                    description = "Dati utente da verificare",
                    content = @Content(schema = @Schema(implementation = LoginRequest.class)))
            LoginRequest loginRequest
    ) {

        Optional<String> token;
        try {
            String result_token = authService.userLogin(loginRequest);
            token = Optional.of(result_token);

        } catch (WrongCredentialsException | UserNotFoundException e) {
            return Response.status(401)
                    .entity(new BasicResponseDTO("Credenziali errate o utente non registrato"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {

            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        LoginResponseDTO response = new LoginResponseDTO("Login effettuato", token.get());
        return Response.status(200)
                .entity(response)
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }
}
