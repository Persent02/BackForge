package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Student;
import it.avbo.backforge.service.model.jpa.Teacher;
import jakarta.ejb.Local;

import java.util.Optional;

@Local
public interface UserDAO {

    void insertStudent(Student student);
    void insertTeacher(Teacher teacher);
    Optional<Student> getStudentByEmail(String email);
    Optional<Teacher> getTeacherByEmail(String email);
}
