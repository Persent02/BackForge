package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "CourseSpecialization")
public class CourseSpecializations {

    @EmbeddedId
    private CourseSpecializationsId id;

    public CourseSpecializations() {}

    public CourseSpecializations(CourseSpecializationsId id) {
        this.id = id;
    }

    public String getName() {
        return id.getName();
    }

    public void setName(String name) {
        id.setName(name);
    }

    public int getCourse_id() {
        return id.getCourse_id();
    }

    public void setCourse_id(int course_id) {
        id.setCourse_id(course_id);
    }
}
