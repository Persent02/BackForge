package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.CourseYears;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface CourseYearsDAO {

    void insertYear(CourseYears courseYears);
    void deleteYear(CourseYears courseYears);
    List<String> getYearsByCourseId(int course_id);
}
