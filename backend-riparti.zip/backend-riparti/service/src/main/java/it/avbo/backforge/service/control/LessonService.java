package it.avbo.backforge.service.control;

import it.avbo.backforge.service.dao.CourseDAO;
import it.avbo.backforge.service.dao.LessonDAO;
import it.avbo.backforge.service.dao.ParticipationDAO;
import it.avbo.backforge.service.exceptions.ResourceNotFoundException;
import it.avbo.backforge.service.model.dto.requests.AbsenceRequest;
import it.avbo.backforge.service.model.dto.responses.LessonResponseDTO;
import it.avbo.backforge.service.model.jpa.Course;
import it.avbo.backforge.service.model.jpa.Lesson;
import it.avbo.backforge.service.utility.EmailService;
import it.avbo.backforge.service.utility.Formatter;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class LessonService {

    @Inject
    ParticipationDAO participationDAO;

    @Inject
    LessonDAO lessonDAO;

    @Inject
    CourseDAO courseDAO;

    /**
     * Metodo del layer di control per l'entità Lesson che gestisce la rimozione di una presenza da una lezione
     * @param request L'oggetto AbsenceRequest contenente i dati ricevuti dal client
     * @param email WIP, l'email dello studente
     * @throws ResourceNotFoundException se la lezione specificata non viene trovata
     */
    public void setLessonAbsence(AbsenceRequest request, String email) throws ResourceNotFoundException {

        //controllo presenza lezione
        Lesson selected_lesson = lessonDAO.getLessonById(request.getLesson_id());
        if (selected_lesson == null) {
            throw new ResourceNotFoundException("Lesson not found");
        }

        //ricerca corso relativo alla lezione
        Course lesson_course = courseDAO.getCourseById(selected_lesson.getCourse_id());

        //cancellazione record presenza
        participationDAO.deleteByLessonIdAndStudentEmail(request.getLesson_id(), email);

        //invio email di notifica al docente
        String message = getAbsenceMessage(email, lesson_course.getTeacher_email(), selected_lesson.getDate().toString(), request.getCause());
        EmailService.sendEmail(lesson_course.getTeacher_email(), message,"Comunicazione RIPARTI | Assenza di uno studente ad una lezione");
    }

    private String getAbsenceMessage(String student_email, String teacher_email, String lesson_date, String cause) {

        //ricavi nome e cognome di docente e studente
        String[] student_name_surname = Formatter.getNameAndSurnameFromEmail(student_email);
        String[] teacher_name_surname = Formatter.getNameAndSurnameFromEmail(teacher_email);


        return "Gentile docente " + teacher_name_surname[0] + " " + teacher_name_surname[1] +
                "\n\n Il team di riparti la avvisa che lo studente " + student_name_surname[0] + " " + student_name_surname[1] + " non riuscirà a partecipare alla lezione del " + lesson_date +
                "\n Lo studente ha inserito come causa il seguente messaggio: "+ cause + " Riparti";
    }

    /**
     * Metodo del layer di control per l'entità Lesson che si occupa di restituire all'utente una lista di lezioni.
     * Se l'utente è uno studente, la lista sarà delle lezioni dei corsi a cui lo studente è iscritto e per cui non ha segnato l'assenza. Se l'utente è un docente, la lista sarà delle lezioni nei corsi creati dal docente
     * @param email l'email dell'utente
     * @return Un array di LessonResponseDTO, corrispondente all'oggetto JSON concordato e rappresentante i dati della lezione
     */
    public LessonResponseDTO[] getLessonsByUser(String email) {
        //ricerca la lista di lezioni per il tipo di utente
        List<Lesson> lessons = new ArrayList<>();
        if (email.endsWith("@avbo.it")) {

            lessons = lessonDAO.getLessonsByTeacher(email);

        } else if (email.endsWith("@aldini.istruzioneer.it")) {

            lessons = lessonDAO.getLessonsByStudent(email);
        }

        //crea l'oggetto di risposta prendendo i dati e trasferendoli nel formato corretto
        LessonResponseDTO[] lesson_response = new LessonResponseDTO[lessons.size()];
        for (int i = 0; i < lessons.size(); i++) {

            Course course = courseDAO.getCourseById(lessons.get(i).getCourse_id());
            lesson_response[i] = new LessonResponseDTO(course.getTitle(), lessons.get(i).getDate().toString(), lessons.get(i).getStart_time(), lessons.get(i).getEnd_time());
        }

        return lesson_response;
    }
}
