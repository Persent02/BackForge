package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Student;
import it.avbo.backforge.service.model.jpa.Teacher;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.PersistenceContextType;
import jakarta.persistence.SynchronizationType;
import jakarta.transaction.Transactional;

import java.util.Optional;

@ApplicationScoped
public class UserDAOImplementation implements UserDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    private EntityManager em;

    @Override
    @Transactional
    public void insertStudent(Student student) {
        em.persist(student);
    }

    @Override
    @Transactional
    public void insertTeacher(Teacher teacher) {
        em.persist(teacher);
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Optional<Student> getStudentByEmail(String email) {
        Student student = em.find(Student.class, email);
        if (student == null)
            return Optional.empty();
        else
            return Optional.of(student);
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Optional<Teacher> getTeacherByEmail(String email) {
        Teacher teacher = em.find(Teacher.class, email);
        if (teacher == null)
            return Optional.empty();
        else
            return Optional.of(teacher);
    }
}
