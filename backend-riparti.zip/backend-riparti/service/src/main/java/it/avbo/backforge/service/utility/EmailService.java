package it.avbo.backforge.service.utility;

import it.avbo.backforge.service.exceptions.EmailSendException;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

@ApplicationScoped
public class EmailService {
    private static final Logger LOGGER = Logger.getLogger(EmailService.class.getName());

    // credenziali e server
    private static final String SMTP_HOST = "mail1.bolo.casa";
    private static final String SMTP_PORT = "465";  // Submission TLS
    private static final String USERNAME  = "noreply.riparti@avbolabs.eu";
    private static final String PASSWORD  = "N5J8VXLLuS7WhimChWSacykNNmpnbN0x";

    public static void sendEmail(String recipient, String content, String subject) {
        Properties props = new Properties();
        props.put("mail.smtp.host", SMTP_HOST);
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.ssl.enable", "true");      // abilita SSL/TLS
        props.put("mail.smtp.ssl.protocols", "TLSv1.2"); // (opzionale)
        props.put("mail.debug", "true");

        // crea session autenticata
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(USERNAME, PASSWORD);
            }
        });
        session.setDebug(true);

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(USERNAME));
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(recipient));
            message.setSubject(subject);
            message.setText(content);

            Transport.send(message);
            LOGGER.log(Level.INFO, "Email inviata con successo a: {0}", recipient);

        } catch (MessagingException e) {
            LOGGER.log(Level.SEVERE, "Errore invio email a: " + recipient, e);
            throw new EmailSendException("Errore invio email " + e.getMessage());
        }
    }
}
