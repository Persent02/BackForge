package it.avbo.backforge.service.view;

import it.avbo.backforge.service.control.LessonService;
import it.avbo.backforge.service.exceptions.ResourceNotFoundException;
import it.avbo.backforge.service.model.dto.requests.AbsenceRequest;
import it.avbo.backforge.service.model.dto.responses.BasicResponseDTO;
import it.avbo.backforge.service.model.dto.responses.LessonsListDTO;
import jakarta.annotation.security.DenyAll;
import jakarta.annotation.security.RolesAllowed;
import it.avbo.backforge.service.model.dto.responses.LessonResponseDTO;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;

@Path("/lesson")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class LessonResource {

    @Inject
    private LessonService lessonService;

    @POST
    @Path("/absence")
    @RolesAllowed("student")
    @Operation(summary = "Segnala un'assenza per uno studente")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "Assenza registrata con successo", content = @Content(mediaType = MediaType.APPLICATION_JSON)),
            @APIResponse(responseCode = "401", description = "Utente non autenticato", content = @Content(mediaType = MediaType.APPLICATION_JSON)),
            @APIResponse(responseCode = "403", description = "Utente non autorizzato ad attivare il corso", content = @Content(mediaType = MediaType.APPLICATION_JSON)),
            @APIResponse(responseCode = "404", description = "Lezione non trovata", content = @Content(mediaType = MediaType.APPLICATION_JSON)),
            @APIResponse(responseCode = "500", description = "Errore interno", content = @Content(mediaType = MediaType.APPLICATION_JSON))
    })
    public Response reportAbsence(
            @RequestBody(
                    description = "Dati necessari per registrare un'assenza",
                    content = @Content(schema = @Schema(implementation = AbsenceRequest.class))
            )
            AbsenceRequest request,
            @Context SecurityContext ctx
            ) {
        try {
            lessonService.setLessonAbsence(request, ctx.getUserPrincipal().getName());

        } catch (ResourceNotFoundException e) {
            return Response.status(404)
                    .entity(new BasicResponseDTO("Lezione non trovata: " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore interno: " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(200)
                .entity(new BasicResponseDTO("Assenza registrata con successo"))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

    @POST
    @Operation(summary = "Restituisce la lista delle lezioni dell’utente autenticato")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Richiesta elaborata con successo",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "403",
                    description = "Accesso non autorizzato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response getLessonsList(@Context SecurityContext ctx) {
        LessonResponseDTO[] response;
        String email = ctx.getUserPrincipal().getName();
        try {
            response = lessonService.getLessonsByUser(email);

        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione: " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(200)
                .entity(new LessonsListDTO("Richiesta elaborata con successo", response))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

}
