package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CourseYearsId implements Serializable {

    private String year;
    private int course_id;

    public CourseYearsId() {}

    public CourseYearsId(String year, int course_id) {
        this.year = year;
        this.course_id = course_id;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof CourseYearsId that)) return false;
        return course_id == that.course_id && Objects.equals(year, that.year);
    }

    @Override
    public int hashCode() {
        return Objects.hash(year, course_id);
    }
}
