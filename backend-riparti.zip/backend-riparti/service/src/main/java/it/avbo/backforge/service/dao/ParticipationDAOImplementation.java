package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Lesson;
import it.avbo.backforge.service.model.jpa.ParticipationId;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.*;

import it.avbo.backforge.service.model.jpa.Participation;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class ParticipationDAOImplementation implements ParticipationDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    private EntityManager em;

    @Inject
    private LessonDAO lessonDAO;

    @Override
    @Transactional
    public void save(Participation participation) {
        em.persist(participation);
    }

    @Override
    @Transactional
    public void deleteByLessonId(int id) {
        List<ParticipationId> result = findByLessonId(id);

        Participation participation;
        for (ParticipationId single_id : result) {
            participation = new Participation(single_id);

            //siccome la rimozione può avvenire soltanto se l'entity è inserita dallo stesso em, va prima controllata l'esistenza dell'entità dentro i record dell'em e nel caso inserita
            em.remove(em.contains(participation) ? participation : em.merge(participation));
        }
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<String> getParticipantsByLesson(int lesson_id) {

        TypedQuery<String> query = em.createQuery("SELECT s.id.student_email FROM Participation s WHERE s.id.lesson_id = :lesson_id", String.class);
        query.setParameter("lesson_id", lesson_id);
        return query.getResultList();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<ParticipationId> findByLessonId(int lessonId) {
        return em.createQuery("SELECT p.id FROM Participation p WHERE p.id.lesson_id = :lessonId", ParticipationId.class)
                .setParameter("lessonId", lessonId)
                .getResultList();
    }

    @Override
    @Transactional
    public void deleteByLessonIdAndStudentEmail(int lessonId, String studentEmail) {
        ParticipationId id = new ParticipationId(lessonId, studentEmail);
        Participation participation = em.find(Participation.class, id);
        if (participation != null) {
            em.remove(em.contains(participation) ? participation : em.merge(participation));
        }
    }

    @Override
    @Transactional
    public void deleteParticipationsByCourse(int courseId) {
        List<Lesson> lessons = lessonDAO.getLessonsByCourse(courseId);

        for (Lesson lesson : lessons) {
            deleteByLessonId(lesson.getId());
        }
    }
}