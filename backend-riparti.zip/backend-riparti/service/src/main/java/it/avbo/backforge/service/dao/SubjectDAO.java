package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Subject;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface SubjectDAO {

    void insertSubject(Subject subject);
    List<Subject> getSubjectsByEmail(String email);
}
