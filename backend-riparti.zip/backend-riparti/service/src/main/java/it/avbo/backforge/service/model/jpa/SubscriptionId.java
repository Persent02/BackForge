package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class SubscriptionId implements Serializable {

    private String student_email;
    private int course_id;

    public SubscriptionId() {}

    public SubscriptionId(String student_email, int course_id) {
        this.student_email = student_email;
        this.course_id = course_id;
    }

    public String getStudent_email() {
        return student_email;
    }

    public void setStudent_email(String student_email) {
        this.student_email = student_email;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof SubscriptionId that)) return false;
        return course_id == that.course_id && Objects.equals(student_email, that.student_email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(student_email, course_id);
    }
}
