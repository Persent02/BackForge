package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

/* classe DTO: da usare nei metodi delle classi control per esporre i dati in una certa struttura */

@Schema(description = "Rappresenta l'entità Docente e viene utilizzata per scambiare i dati con il client")
public class TeacherDTO {
    @Schema(description = "L'email del docente @avbo.it", examples = "nadia.amaroli@avbo.it")
    private String email;

    @Schema(description = "La password del docente", examples = "L2kEIxoRCDREPFq")
    private String password;

    @Schema(description = "Il nome del docente", examples = "Nadia")
    private String name;

    @Schema(description = "Il cognome del docente", examples = "Amaroli")
    private String surname;

    @Schema(description = "Il codice dell'avatar del docente", examples = {"T1", "T3"})
    private String avatar; //l'avatar viene scelto randomicamente tra quelli presenti

    @Schema(description = "L'elenco delle materie insegnate dal docente", examples = {"Italiano", "Storia"})
    private String[] subjects;

    public TeacherDTO() {}

    public TeacherDTO(String email, String password, String name, String surname, String avatar, String[] subjects) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.avatar = avatar;
        this.subjects = subjects;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String[] getSubjects() {
        return subjects;
    }

    public void setSubjects(String[] subjects) {
        this.subjects = subjects;
    }
}
