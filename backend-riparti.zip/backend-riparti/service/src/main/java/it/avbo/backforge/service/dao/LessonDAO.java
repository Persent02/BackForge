package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Lesson;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface LessonDAO {

    void insertLesson(Lesson lesson);
    void deleteLesson(Lesson lesson);
    List<Lesson> getLessonsByCourse(int course_id);
    Lesson getLessonById(int lesson_id);
    void deleteLessonsByCourse(int courseId);
    List<Lesson> getLessonsByStudent(String studentEmail);
    List<Lesson> getLessonsByTeacher(String teacherEmail);
}
