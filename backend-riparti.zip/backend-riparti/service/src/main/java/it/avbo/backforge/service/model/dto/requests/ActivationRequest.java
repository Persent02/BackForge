package it.avbo.backforge.service.model.dto.requests;

import org.eclipse.microprofile.openapi.annotations.media.Schema;
@Schema(description = "La richiesta da inviare al servizio contenente l'id del corso da attivare ")
public class ActivationRequest {

    @Schema(description ="id del corso", examples ="123")
    private Integer course_id;

    public ActivationRequest() {}

    public ActivationRequest(Integer course_id) {
        this.course_id = course_id;
    }

    public Integer getCourse_id() {
        return course_id;
    }

    public void setCourse_id(Integer course_id) {
        this.course_id = course_id;
    }



}
