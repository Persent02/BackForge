package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.*;

/* Entità JPA Docente, rappresenta la tabella Docente nel DB */

@Entity
@Table(name = "Teacher")
public class Teacher {

    @Id
    private String email;

    private byte[] password;
    private String name;
    private String surname;
    private String avatar;
    private byte[] salt;

    public Teacher() {}

    public Teacher(String email, byte[] password, String name, String surname, String avatar, byte[] salt) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.avatar = avatar;
        this.salt = salt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public byte[] getPassword() {
        return password;
    }

    public void setPassword(byte[] password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public byte[] getSalt() {
        return salt;
    }

    public void setSalt(byte[] salt) {
        this.salt = salt;
    }
}
