package it.avbo.backforge.service.control;

import it.avbo.backforge.service.dao.CourseDAO;
import it.avbo.backforge.service.dao.LessonDAO;
import it.avbo.backforge.service.dao.ParticipationDAO;
import it.avbo.backforge.service.dao.SubscriptionDAO;
import it.avbo.backforge.service.exceptions.ResourceNotFoundException;
import it.avbo.backforge.service.model.jpa.*;
import it.avbo.backforge.service.utility.EmailService;
import it.avbo.backforge.service.utility.Formatter;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;

@ApplicationScoped
public class SubscriptionService {

    @Inject
    private CourseDAO courseDAO;

    @Inject
    private LessonDAO lessonDAO;

    @Inject
    private SubscriptionDAO subscriptionDAO;

    @Inject
    private ParticipationDAO participationDAO;

    /**
     * Metodo del layer di Control per l'entità Course che si occupa di gestire l'iscrizione di uno studente ad un corso
     * @param course_id l'id del corso a cui ci si vuole iscrivere
     * @param email il token di autenticazione dello studente che effettua la richiesta
     * @throws ResourceNotFoundException se l'id del corso non corrisponde ad un corso esistente
     */
    public void subscribeToCourse(int course_id, String email) throws ResourceNotFoundException {

        // controllo esistenza corso
        Course selected_course = courseDAO.getCourseById(course_id);
        if (selected_course == null) {
            throw new ResourceNotFoundException("Course not found");
        }

        //inserimento iscrizione
        SubscriptionId sub_id = new SubscriptionId();
        sub_id.setCourse_id(course_id);
        sub_id.setStudent_email(email);

        Subscription subscription = new Subscription(sub_id);
        subscriptionDAO.save(subscription);

        //ricerca lezioni corso e inserimento partecipazione per ogni lezione
        List<Lesson> lessons = lessonDAO.getLessonsByCourse(course_id);
        for (Lesson lesson : lessons) {

            ParticipationId id = new ParticipationId(lesson.getId(), email);
            Participation participation = new Participation(id);
            participationDAO.save(participation);
        }

        String message = getSubscriptionMessage(email, selected_course.getTeacher_email(), selected_course.getTitle());

        //invio email al docente
        EmailService.sendEmail(selected_course.getTeacher_email(), message, "Comunicazione RIPARTI | Uno studente si è iscritto ad un suo corso");
    }

    private String getSubscriptionMessage(String student_email, String teacher_email, String course_name) {

        //ricavi nome e cognome di docente e studente
        String[] student_name_surname = Formatter.getNameAndSurnameFromEmail(student_email);
        String[] teacher_name_surname = Formatter.getNameAndSurnameFromEmail(teacher_email);


        return "Gentile docente " + teacher_name_surname[0] + " " + teacher_name_surname[1] + "\n\n Il team di riparti la avvisa che lo studente " + student_name_surname[0] + " " + student_name_surname[1] + " si è iscritto al suo corso " + course_name + "\n Riparti";

    }

    /**
     * Metodo del layer di control per l'entità Subscription che gestisce la procedura di disiscrizione di un utente da un corso
     * @param course_id l'id del corso a cui ci si vuole iscrivere
     * @param email l'email dello studente
     * @throws ResourceNotFoundException se l'id del corso non corrisponde ad un corso esistente
     */
    public void unsubscribeFromCourse(int course_id, String email) throws ResourceNotFoundException {
        //controllo esistenza corso
        Course selected_course = courseDAO.getCourseById(course_id);
        if (selected_course == null) {
            throw new ResourceNotFoundException("Course not found");
        }

        // ricerca lezioni del corso per eliminare la partecipazione alle lezioni
        List<Lesson> course_lessons = lessonDAO.getLessonsByCourse(course_id);
        for (Lesson lesson : course_lessons) {
            participationDAO.deleteByLessonIdAndStudentEmail(lesson.getId(), email); //TODO: quando il jwt è sistemato rimpiazza con l'email all'interno e rimuovi il parametro
        }

        //eliminazione record iscrizione
        subscriptionDAO.deleteByStudentAndCourse(email, course_id); //TODO: quando il jwt è sistemato rimpiazza con l'email all'interno e rimuovi il parametro

        //invio email di notifica al docente
        String message = getUnsubscriptionMessage(email, selected_course.getTeacher_email(), selected_course.getTitle());
        EmailService.sendEmail(selected_course.getTeacher_email(), message, "Comunicazione RIPARTI | Uno studente si è disiscritto da un suo corso");
    }

    private String getUnsubscriptionMessage(String student_email, String teacher_email, String course_name) {

        //ricavi nome e cognome di docente e studente
        String[] student_name_surname = Formatter.getNameAndSurnameFromEmail(student_email);
        String[] teacher_name_surname = Formatter.getNameAndSurnameFromEmail(teacher_email);


        return "Gentile docente " + teacher_name_surname[0] + " " + teacher_name_surname[1] + "\n\n Il team di riparti la avvisa che lo studente " + student_name_surname[0] + " " + student_name_surname[1] + " ha annullato l'iscrizione dal suo corso " + course_name + "\n Riparti";

    }
}
