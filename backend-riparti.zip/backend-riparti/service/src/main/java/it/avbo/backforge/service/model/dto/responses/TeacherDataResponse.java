package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'oggetto JSON corrispondente alla risposta per l'api di invio dati utente nel caso di un docente")
public class TeacherDataResponse {

    @Schema(description = "Il messaggio della risposta")
    private String message;

    @Schema(description = "L'oggetto con i dati del docente")
    private TeacherDTO teacher;

    public TeacherDataResponse() {}

    public TeacherDataResponse(String message, TeacherDTO teacher) {
        this.message = message;
        this.teacher = teacher;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public TeacherDTO getTeacher() {
        return teacher;
    }

    public void setTeacher(TeacherDTO teacher) {
        this.teacher = teacher;
    }
}
