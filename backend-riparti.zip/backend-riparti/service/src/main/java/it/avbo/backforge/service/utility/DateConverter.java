package it.avbo.backforge.service.utility;

import it.avbo.backforge.service.exceptions.DataNotValidException;

import java.util.Calendar;
import java.util.TimeZone;

/**
 * Classe per la conversione di una data dal formato stringa a long.
 */
public class DateConverter {

    /**
     * Metodo statico che converte una stringa rappresentante una data nel formato YYYY-MM-DD in un valore long.
     * La conversione avviene estraendo giorno, mese e anno e convertendoli in secondi.
     *
     * @param dateString La stringa della data in formato DD/MM/AAAA
     * @return Il valore long corrispondente alla data in secondi
     * @throws IllegalArgumentException Se il formato della data non è valido
     */
    public static long convertDateToLong(String dateString) throws DataNotValidException {
        int[] dateParts = extractDateParts(dateString);
        int day = dateParts[0];
        int month = dateParts[1] - 1; // Calendar usa indici da 0 a 11 per i mesi
        int year = dateParts[2];

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeZone(TimeZone.getDefault());
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, month);
        calendar.set(Calendar.DAY_OF_MONTH, day);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTimeInMillis();
    }

    /**
     * Metodo di utilità per estrarre giorno, mese e anno da una stringa nel formato YYYY-MM-DD.
     *
     * @param dateString La stringa della data in formato YYYY-MM-DD
     * @return Un array di interi con giorno, mese e anno [giorno, mese, anno]
     * @throws IllegalArgumentException Se il formato della data non è valido
     */
    private static int[] extractDateParts(String dateString) throws DataNotValidException {
        if (dateString == null || !dateString.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new DataNotValidException("Il formato della data deve essere YYYY-MM-DD");
        }

        String[] parts = dateString.split("-");
        int day = Integer.parseInt(parts[2]);
        int month = Integer.parseInt(parts[1]);
        int year = Integer.parseInt(parts[0]);

        // Validazione basilare
        if (day < 1 || day > 31 || month < 1 || month > 12) {
            throw new DataNotValidException("Valori di giorno o mese non validi");
        }

        return new int[] {day, month, year};
    }

    /**
     * Metodo di utilità per la conversione di ore e minuti in un orario in formato HH:MM:SS in un array di interi
     *
     * @param timeString la stringa dell'ora in formato HH:MM:SS
     * @return Un array di interi contenente i valori dell'ora e dei minuti
     * @throws IllegalArgumentException Se il formato dell'orario non è corretto
     */
    public static int[] covertTimeToIntArray(String timeString) throws DataNotValidException {
        if (timeString == null || timeString.isEmpty() || !timeString.matches("\\d{2}:\\d{2}:\\d{2}")) {
            throw new DataNotValidException("Il formato dell'ora deve essere HH:MM:SS'");
        }

        String[] parts = timeString.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);

        if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
            throw new DataNotValidException("I valori di ora o minuto non validi'");
        }

        return new int[] {hour, minute};
    }

    /**
     * Metodo di utilità per convertire una data in ore e minuti in un valore in soli minuti
     *
     * @param dateArray array di interi contenente i valori di ore e minuti
     * @return Un valore intero contenente l'istante dell'ora in minuti della giornata
     */
    public static int convertStandardTimeToMinutes(int[] dateArray) {

        return dateArray[0] * 60 + dateArray[1];
    }
}