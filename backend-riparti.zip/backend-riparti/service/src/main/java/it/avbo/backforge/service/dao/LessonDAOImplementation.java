package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Lesson;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class LessonDAOImplementation implements LessonDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    private EntityManager em;

    @Override
    @Transactional
    public void insertLesson(Lesson lesson){
        em.persist(lesson);
    }

    @Override
    @Transactional
    public void deleteLesson(Lesson lesson){
        em.remove(lesson);
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Lesson> getLessonsByCourse(int course_id){

        TypedQuery<Lesson> query = em.createQuery(
                "SELECT l FROM Lesson l WHERE l.course_id = :course_id", Lesson.class
        );
        query.setParameter("course_id", course_id);
        return query.getResultList();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Lesson getLessonById(int lesson_id){
        return em.find(Lesson.class, lesson_id);
    }

    @Override
    @Transactional
    public void deleteLessonsByCourse(int courseId) {
        List<Lesson> lessons = getLessonsByCourse(courseId);
        for (Lesson lesson : lessons) {
            deleteLesson(lesson);
        }
    }
    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Lesson> getLessonsByStudent(String studentEmail) {

        TypedQuery<Lesson> query = em.createQuery(
                "SELECT l FROM Lesson l WHERE l.course_id IN (SELECT s.id.course_id FROM Subscription s WHERE s.id.student_email = :studentEmail) AND EXISTS (SELECT p FROM Participation p WHERE p.id.lesson_id = l.id AND p.id.student_email = :studentEmail)", Lesson.class
        );
        query.setParameter("studentEmail", studentEmail);
        return query.getResultList();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Lesson> getLessonsByTeacher(String teacherEmail) {

        TypedQuery<Lesson> query = em.createQuery(
                "SELECT l FROM Lesson l WHERE l.course_id IN (SELECT c.id FROM Course c WHERE c.teacher_email = :teacherEmail)", Lesson.class
        );
        query.setParameter("teacherEmail", teacherEmail);
        return query.getResultList();
    }

}
