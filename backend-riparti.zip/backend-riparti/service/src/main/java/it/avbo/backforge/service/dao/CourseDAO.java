package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Course;
import jakarta.ejb.Local;

import java.util.List;

@Local
public interface CourseDAO {
    Course getCourseById(int id);
    List<Course> getCoursesByStudentEmail(String student_email);
    List<Course> getCoursesByTeacherEmail(String teacher_email);
    void insertCourse(Course course);
    void activateCourse(int courseId);
    void deleteCourseById(int courseId);
}
