package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

//TODO: crea un secondo DTO con tutti i dati di una lezione

@Schema(description = "Rappresenta la struttura della lezione nei dati di un singolo corso")
public class SimpleLessonDTO {

    @Schema(description = "La data della lezione", examples = "25/4/2025")
    private String date;

    @Schema(description = "L'ora di inizio della lezione", examples = "14:00")
    private String start_time;

    @Schema(description = "L'ora di fine della lezione", examples = "16:00")
    private String end_time;

    @Schema(description = "L'array delle email dei partecipanti a quella lezione", examples = {"francesco.sorghi@aldini.istruzioneer.it", "lorenzo.diduca@aldini.istruzioneer.it"})
    private String[] participants;
    
    public SimpleLessonDTO() {}

    public SimpleLessonDTO(String date, String start_time, String end_time, String[] participants) {
        this.date = date;
        this.start_time = start_time;
        this.end_time = end_time;
        this.participants = participants;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String[] getParticipants() {
        return participants;
    }

    public void setParticipants(String[] participants) {
        this.participants = participants;
    }
}
