package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "Subscription")
public class Subscription {

    @EmbeddedId
    private SubscriptionId id;

    public Subscription() {}

    public Subscription(SubscriptionId id) {
        this.id = id;
    }

    public String getStudent_email(){
        return id.getStudent_email();
    }

    public void setStudent_email(String student_email){
        id.setStudent_email(student_email);
    }

    public int getCourse_id(){
        return id.getCourse_id();
    }

    public void setCourse_id(int course_id){
        id.setCourse_id(course_id);
    }
}
