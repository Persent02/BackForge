package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Subscription;
import it.avbo.backforge.service.model.jpa.SubscriptionId;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class SubscriptionDAOImplementation implements SubscriptionDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    EntityManager em;

    @Override
    @Transactional
    public void save(Subscription subscription) {
        em.persist(subscription);
    }

    @Override
    @Transactional
    public void deleteByCourseId(int course_id) {

        List<SubscriptionId> result = findByCourseId(course_id);

        Subscription sub;

        for (SubscriptionId single_id : result) {

            sub = new Subscription(single_id);
            em.remove(em.contains(sub) ? sub : em.merge(sub));
        }
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<String> getSubscribedByCourse(int course_id) {

        TypedQuery<String> query = em.createQuery("SELECT s.id.student_email FROM Subscription s WHERE s.id.course_id = :course_id", String.class);
        query.setParameter("course_id", course_id);
        return query.getResultList();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<SubscriptionId> findByCourseId(int course_id) {
        return em.createQuery("SELECT s.id FROM Subscription s WHERE s.id.course_id = :courseId", SubscriptionId.class)
                .setParameter("courseId", course_id)
                .getResultList();
    }

    @Override
    @Transactional
    public void deleteByStudentAndCourse(String studentEmail, int courseId) {
        em.createQuery("DELETE FROM Subscription s WHERE s.id.student_email = :email AND s.id.course_id = :courseId")
                .setParameter("email", studentEmail)
                .setParameter("courseId", courseId)
                .executeUpdate();
    }
}