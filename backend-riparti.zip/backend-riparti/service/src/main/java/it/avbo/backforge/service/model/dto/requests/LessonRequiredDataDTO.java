package it.avbo.backforge.service.model.dto.requests;

import org.eclipse.microprofile.openapi.annotations.media.Schema;


@Schema(description = "Rappresenta i dati di una lezione che devono essere inviati al servizio")
public class LessonRequiredDataDTO {

    @Schema(description = "La data della lezione", examples = "2025-03-25")
    private String date;

    @Schema(description = "L'orario di inizio della lezione", examples = "14:30:00")
    private String start_time;

    @Schema(description = "L'orario di inizio della lezione", examples = "16:30:00")
    private String end_time;

    public LessonRequiredDataDTO() {}

    public LessonRequiredDataDTO(String date, String start_time, String end_time) {
        this.date = date;
        this.start_time = start_time;
        this.end_time = end_time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }
}
