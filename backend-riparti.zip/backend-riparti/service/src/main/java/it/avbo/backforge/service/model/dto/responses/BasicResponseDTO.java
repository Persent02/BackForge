package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "rappresenta l'oggetto JSON della risposta base (solo campo message) inviato al client ")
public class BasicResponseDTO {

    @Schema(description = "il messaggio allegato alla risposta", examples = "Utente registrato")
    String message;

    public BasicResponseDTO() {}

    public BasicResponseDTO(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
