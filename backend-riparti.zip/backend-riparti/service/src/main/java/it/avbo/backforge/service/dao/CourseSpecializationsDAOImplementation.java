package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.CourseSpecializations;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class CourseSpecializationsDAOImplementation implements CourseSpecializationsDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    private EntityManager em;

    @Override
    @Transactional
    public void insertSpecialization(CourseSpecializations courseSpecialization) {
        em.persist(courseSpecialization);
    }

    @Override
    @Transactional
    public void deleteSpecialization(CourseSpecializations courseSpecialization) {
        em.remove(em.contains(courseSpecialization) ? courseSpecialization : em.merge(courseSpecialization));
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<String> getSpecializationsByCourseId(int course_id) {

        TypedQuery<String> query = em.createQuery(
                "SELECT cs.id.name FROM CourseSpecializations cs WHERE cs.id.course_id = :course_id", String.class
        );
        query.setParameter("course_id", course_id);
        return query.getResultList();
    }
}
