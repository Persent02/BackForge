package it.avbo.backforge.service.model.dto.requests;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "I dati che vengono inviati dall'utente quando vuole registrarsi")
public class RegistrationRequest {

    @Schema(description = "L'email dello studente @aldini.istruzioneer.it", examples = "francesco.sorghi@aldini.istruzioneer.it")
    private String email;

    @Schema(description = "La password dello studente", examples = "L2kEIxoRCDREPFq?")
    private String password;

    @Schema(description = "Il nome dello studente", examples = "Francesco")
    private String name;

    @Schema(description = "Il cognome dello studente", examples = "Sorghi")
    private String surname;

    @Schema(description = "La classe dello studente", examples = "5BIN")
    private String class_name;

    @Schema(description = "Le materie insegnate dal docente", examples = {"Italiano", "Storia"})
    private String[] subjects;

    public RegistrationRequest() {}

    public RegistrationRequest(String email, String password, String name, String surname, String class_name) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.class_name = class_name;
    }

    public RegistrationRequest(String email, String password, String name, String surname, String[] subjects) {
        this.email = email;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.subjects = subjects;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public String[] getSubjects() {
        return subjects;
    }

    public void setSubjects(String[] subjects) {
        this.subjects = subjects;
    }
}
