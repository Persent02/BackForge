package it.avbo.backforge.service.security;

import it.avbo.backforge.service.exceptions.DataNotValidException;
import it.avbo.backforge.service.model.dto.requests.LoginRequest;
import it.avbo.backforge.service.model.dto.requests.RegistrationRequest;

public class UserValidator {

    public static void validateRegistrationData(RegistrationRequest request) throws DataNotValidException {

        //controllo validità email con eccezione custom
        validateUserEmail(request.getEmail());

        //controllo presenza dati richiesta
        if (request.getName() == null || request.getName().isEmpty()) {
            throw new DataNotValidException("Nome" + request.getName() + "non valido");
        }

        if (request.getSurname() == null || request.getSurname().isEmpty()) {
            throw new DataNotValidException("Cognome" + request.getSurname() + "non valido");
        }

        //controllo validità password
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!$%&?/*])[A-Za-z\\d!$%&?/*]{8,}$";
        if (request.getPassword() == null || request.getPassword().isEmpty() || !(request.getPassword().matches(regex))) {
            throw new DataNotValidException("Password" + request.getPassword() + "non valida");
        }

        if ((request.getSubjects() == null || request.getSubjects().length == 0) == (request.getClass_name() == null || request.getClass_name().isEmpty())) {
            throw new DataNotValidException("Classe o materie docente non valide");
        }
    }

    public static void validateLoginData(LoginRequest request) throws DataNotValidException {

        //controllo validità email con eccezione custom
        validateUserEmail(request.getEmail());

        //controllo presenza password
        if (request.getPassword() == null || request.getPassword().isEmpty()) {
            throw new DataNotValidException("Password" + request.getPassword() + "non valida");
        }
    }

    private static void validateUserEmail(String email) {
        if (email == null || email.isEmpty()) {
            throw new DataNotValidException("Email " + email + " non presente");
        }

        if (!(email.endsWith("@avbo.it") || email.endsWith("@aldini.istruzioneer.it"))) {
            throw new DataNotValidException("Email " + email + " non valida");
        }
    }
}
