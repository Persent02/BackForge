package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class CourseSpecializationsId implements Serializable {

    private String name;
    private int course_id;

    public CourseSpecializationsId() {}

    public CourseSpecializationsId(String name, int course_id) {
        this.name = name;
        this.course_id = course_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if(!(o instanceof CourseSpecializationsId that)) return false;
        return Objects.equals(name, that.name)
                && Objects.equals(course_id, that.course_id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, course_id);
    }
}
