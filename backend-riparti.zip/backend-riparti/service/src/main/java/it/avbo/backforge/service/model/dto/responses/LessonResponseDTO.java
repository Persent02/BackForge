package it.avbo.backforge.service.model.dto.responses;

public class LessonResponseDTO {
    private String course_name;
    private String date;
    private String start_time;
    private String end_time;

    public LessonResponseDTO() {}

    public LessonResponseDTO(String course_name, String date, String start_time, String end_time) {
        this.course_name = course_name;
        this.date = date;
        this.start_time = start_time;
        this.end_time = end_time;
    }

    // Getters and setters
    public String getCourseName() {
        return course_name;
    }

    public void setCourseName(String course_name) {
        this.course_name = course_name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return start_time;
    }

    public void setStartTime(String start_time) {
        this.start_time = start_time;
    }

    public String getEndTime() {
        return end_time;
    }

    public void setEndTime(String end_time) {
        this.end_time = end_time;
    }
}