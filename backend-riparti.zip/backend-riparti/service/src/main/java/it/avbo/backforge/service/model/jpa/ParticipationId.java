package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class ParticipationId implements Serializable {

    private int lesson_id;
    private String student_email;

    public ParticipationId() {}

    public ParticipationId(int lesson_id, String student_email) {
        this.lesson_id = lesson_id;
        this.student_email = student_email;
    }

    public int getLesson_id() {
        return lesson_id;
    }

    public void setLesson_id(int lesson_id) {
        this.lesson_id = lesson_id;
    }

    public String getStudent_email() {
        return student_email;
    }

    public void setStudent_email(String student_email) {
        this.student_email = student_email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if(!(o instanceof ParticipationId that)) return false;
        return Objects.equals(lesson_id, that.lesson_id)
                && Objects.equals(student_email, that.student_email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lesson_id, student_email);
    }
}
