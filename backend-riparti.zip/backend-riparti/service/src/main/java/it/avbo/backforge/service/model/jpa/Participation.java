package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "Participation")
public class Participation {

    @EmbeddedId
    private ParticipationId id;

    public Participation() {}

    public Participation(ParticipationId id) {
        this.id = id;
    }

    public int GetLesson_id(){
        return id.getLesson_id();
    }

    public String GetStudent_email(){
        return id.getStudent_email();
    }

    public void SetLesson_id(int lesson_id){
        id.setLesson_id(lesson_id);
    }

    public void SetStudent_email(String student_email){
        id.setStudent_email(student_email);
    }
}
