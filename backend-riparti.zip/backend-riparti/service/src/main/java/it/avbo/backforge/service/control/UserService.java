package it.avbo.backforge.service.control;

import it.avbo.backforge.service.dao.SubjectDAO;
import it.avbo.backforge.service.dao.UserDAO;
import it.avbo.backforge.service.exceptions.ResourceNotFoundException;
import it.avbo.backforge.service.model.dto.responses.StudentDTO;
import it.avbo.backforge.service.model.dto.responses.TeacherDTO;
import it.avbo.backforge.service.model.jpa.Student;
import it.avbo.backforge.service.model.jpa.Subject;
import it.avbo.backforge.service.model.jpa.Teacher;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@ApplicationScoped
public class UserService {

    @Inject
    UserDAO userDAO;

    @Inject
    SubjectDAO subjectDAO;

    /**
     * Metodo del layer di control per l'entità Student che ritorna tutti i dati dello studente memorizzati dentro l'apposita tabella
     * @param email WIP l'email dello studente
     * @return L'oggetto StudentDTO corrispondente all'oggetto JSON contenente i dati dello studente
     * @throws ResourceNotFoundException se l'utente non esiste
     */
    public StudentDTO getStudentData(String email) throws ResourceNotFoundException {

        Optional<Student> student_research = userDAO.getStudentByEmail(email);
        if(student_research.isEmpty()) {
            throw new ResourceNotFoundException("Student not found");
        }
        Student student = student_research.get();

        StudentDTO response = new StudentDTO();
        response.setEmail(student.getEmail());
        response.setName(student.getName());
        response.setSurname(student.getSurname());
        response.setAvatar(student.getAvatar());
        response.setClass_name(student.getClass_name());

        return response;
    }

    /**
     * Metodo del layer di control per l'entità Teacher che ritorna tutti i dati del docente memorizzati dentro l'apposita tabella
     * @param email WIP l'email del docente
     * @return L'oggetto StudentDTO corrispondente all'oggetto JSON contenente i dati del docente
     * @throws ResourceNotFoundException se l'utente non esiste
     */
    public TeacherDTO getTeacherData(String email) throws ResourceNotFoundException {

        Optional<Teacher> teacher_research = userDAO.getTeacherByEmail(email);
        if(teacher_research.isEmpty()) {
            throw new ResourceNotFoundException("Student not found");
        }
        Teacher teacher = teacher_research.get();

        List<Subject> teacher_subjects = subjectDAO.getSubjectsByEmail(email);
        List<String> subjects_names = new ArrayList<>();
        for(Subject subject : teacher_subjects) {
            subjects_names.add(subject.getNome());
        }

        TeacherDTO response = new TeacherDTO();
        response.setEmail(teacher.getEmail());
        response.setName(teacher.getName());
        response.setSurname(teacher.getSurname());
        response.setAvatar(teacher.getAvatar());
        response.setSubjects(subjects_names.toArray(new String[0]));

        return response;
    }
}
