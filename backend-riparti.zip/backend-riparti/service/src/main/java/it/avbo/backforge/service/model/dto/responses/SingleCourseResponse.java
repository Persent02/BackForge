package it.avbo.backforge.service.model.dto.responses;

import it.avbo.backforge.service.model.dto.SingleCourseDTO;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'oggetto JSON inviato al client contenente i dati di un singolo corso")
public class SingleCourseResponse {

    @Schema(description = "Il messaggio di stato della richiesta", examples = "Richiesta elaborata con successo")
    private String message;

    @Schema(description = "L'oggetto contenente le informazioni sul corso")
    private SingleCourseDTO course;

    public SingleCourseResponse () {}

    public SingleCourseResponse(String message, SingleCourseDTO course) {
        this.message = message;
        this.course = course;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public SingleCourseDTO getCourse() {
        return course;
    }

    public void setCourse(SingleCourseDTO course) {
        this.course = course;
    }
}
