package it.avbo.backforge.service.model.jpa;

/*
 * Nel caso la chiave primaria sia composta da più di un attributo implementare una seconda classe che definisce la chiave composta. La struttura deve
 * seguire quella di questa sotto
 */

import jakarta.persistence.Embeddable;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class SubjectId implements Serializable {
    private String name;
    private String teacher_email;

    public SubjectId() {}

    public SubjectId(String name, String teacher_email) {
        this.name = name;
        this.teacher_email = teacher_email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTeacher_email() {
        return teacher_email;
    }

    public void setTeacher_email(String teacher_email) {
        this.teacher_email = teacher_email;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof SubjectId that)) return false;
        return Objects.equals(name, that.name) &&
                Objects.equals(teacher_email, that.teacher_email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, teacher_email);
    }
}