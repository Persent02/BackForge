package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.ParticipationId;
import jakarta.ejb.Local;

import it.avbo.backforge.service.model.jpa.Participation;
import java.util.List;

@Local
public interface ParticipationDAO {
    List<String> getParticipantsByLesson(int lesson_id);
    void save(Participation participation);
    void deleteByLessonId(int id);
    List<ParticipationId> findByLessonId(int lessonId);
    void deleteByLessonIdAndStudentEmail(int lessonId, String studentEmail);
    void deleteParticipationsByCourse(int courseId);
}
