package it.avbo.backforge.service.model.dto.requests;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'oggetto JSON da inviare all'endpoint course/create per creare il corso")
public class CourseInputDataDTO {

    @Schema(description = "Il titolo del corso", examples = "Programmazione in Java")
    private String title;

    @Schema(description = "Il tipo del corso, se di recupero o di potenziamento", examples = "Potenziamento")
    private String type;

    @Schema(description = "La materia legata al corso", examples = "Informatica")
    private String subject;

    @Schema(description = "La descrizione del corso", examples = "Corso di potenziamento incentrato sulla programmazione ad oggetti in Java")
    private String description;

    @Schema(description = "Il numero minimo di partecipanti", examples = "10")
    private int min_participants;

    @Schema(description = "Il numero massimo di partecipanti", examples = "20")
    private int max_participants;

    @Schema(description = "Gli anni a cui è rivolto il corso", examples = {"terza", "quarta", "quinta"})
    private String[] years;

    @Schema(description = "Gli indirizzi a cui è rivolto il corso", examples = {"informatica", "elettronica"})
    private String[] specializations;

    @Schema(description = "Le lezioni del corso, specificando data, ora di inizio e di fine per ognuno")
    private LessonRequiredDataDTO[] lessons;

    public CourseInputDataDTO() {}

    public CourseInputDataDTO(String title, String type, String subject, String description, int min_participants, int max_participants, String[] years, String[] specializations, LessonRequiredDataDTO[] lessons) {
        this.title = title;
        this.type = type;
        this.subject = subject;
        this.description = description;
        this.min_participants = min_participants;
        this.max_participants = max_participants;
        this.years = years;
        this.specializations = specializations;
        this.lessons = lessons;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getMin_participants() {
        return min_participants;
    }

    public void setMin_participants(int min_participants) {
        this.min_participants = min_participants;
    }

    public int getMax_participants() {
        return max_participants;
    }

    public void setMax_participants(int max_participants) {
        this.max_participants = max_participants;
    }

    public String[] getYears() {
        return years;
    }

    public void setYears(String[] years) {
        this.years = years;
    }

    public String[] getSpecializations() {
        return specializations;
    }

    public void setSpecializations(String[] specializations) {
        this.specializations = specializations;
    }

    public LessonRequiredDataDTO[] getLessons() {
        return lessons;
    }

    public void setLessons(LessonRequiredDataDTO[] lessons) {
        this.lessons = lessons;
    }
}
