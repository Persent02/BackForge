package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.*;

import java.security.SecureRandom;

@Entity
@Table(name = "Course")
public class Course {

    @Id
    private int id;

    private String title;
    private String subject;
    private int num_min;
    private int num_max;
    private String description;
    private String teacher_email;
    private String status;
    private String type;

    public Course() {}

    public Course(String title, String subject, int num_min, int num_max, String description, String teacher_email, String status, String type) {
        this.title = title;
        this.subject = subject;
        this.num_min = num_min;
        this.num_max = num_max;
        this.description = description;
        this.teacher_email = teacher_email;
        this.status = status;
        this.type = type;

        SecureRandom random = new SecureRandom();
        this.id = random.nextInt(100000);
    }

    public Course(Integer id, String title, String subject, Integer num_min, Integer num_max, String description, String teacher_email, String status, String type) {
        this.id = id;
        this.title = title;
        this.subject = subject;
        this.num_min = num_min;
        this.num_max = num_max;
        this.description = description;
        this.teacher_email = teacher_email;
        this.status = status;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getNum_min() {
        return num_min;
    }

    public void setNum_min(int num_min) {
        this.num_min = num_min;
    }

    public int getNum_max() {
        return num_max;
    }

    public void setNum_max(int num_max) {
        this.num_max = num_max;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTeacher_email() {
        return teacher_email;
    }

    public void setTeacher_email(String teacher_email) {
        this.teacher_email = teacher_email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
