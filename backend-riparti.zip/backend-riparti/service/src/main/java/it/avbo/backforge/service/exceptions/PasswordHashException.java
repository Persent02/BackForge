package it.avbo.backforge.service.exceptions;

public class PasswordHashException extends RuntimeException {
  public PasswordHashException(String message) {
    super(message);
  }
}
