package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "CourseYear")
public class CourseYears {

    @EmbeddedId
    private CourseYearsId id;

    public CourseYears() {}

    public CourseYears(CourseYearsId id) {
        this.id = id;
    }

    public String getYear() {
        return id.getYear();
    }

    public void setYear(String year) {
        id.setYear(year);
    }

    public int getCourse_id() {
        return id.getCourse_id();
    }

    public void setCourse_id(int course_id) {
        id.setCourse_id(course_id);
    }
}
