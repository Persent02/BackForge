package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Subject;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.PersistenceContextType;
import jakarta.persistence.SynchronizationType;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class SubjectDAOImplementation implements SubjectDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    private EntityManager em;

    @Override
    @Transactional
    public void insertSubject(Subject subject) {
        em.persist(subject);
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Subject> getSubjectsByEmail(String email) {
        return em.createQuery("SELECT M FROM Subject as M WHERE id.teacher_email = :email", Subject.class)
                .setParameter("email", email)
                .getResultList();
    }
}
