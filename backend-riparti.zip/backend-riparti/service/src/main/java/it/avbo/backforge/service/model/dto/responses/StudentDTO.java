package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'entità Studente e viene utilizzata per scambiare i dati relativi allo studente con il client")
public class StudentDTO {

    @Schema(description = "L'email dello studente @aldini.istruzioneer.it", examples = "francesco.sorghi@aldini.istruzioneer.it")
    private String email;

    @Schema(description = "Il nome dello studente", examples = "Francesco")
    private String name;

    @Schema(description = "Il cognome dello studente", examples = "Sorghi")
    private String surname;

    @Schema(description = "Il codice dell'avatar dello studente", examples = {"S1", "S3"})
    private String avatar; //l'avatar viene scelto randomicamente tra quelli presenti

    @Schema(description = "La classe dello studente", examples = "5BIN")
    private String class_name;

    public StudentDTO() {}

    public StudentDTO(String email, String name, String surname, String avatar, String class_name) {
        this.email = email;
        this.name = name;
        this.surname = surname;
        this.avatar = avatar;
        this.class_name = class_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }
}
