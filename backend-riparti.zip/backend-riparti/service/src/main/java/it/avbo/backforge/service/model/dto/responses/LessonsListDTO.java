package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'oggetto JSON di risposta che contiene la lista di lezioni per l'utente")
public class LessonsListDTO {

    @Schema(description = "Il messaggio di stato della risposta", examples = "Richiesta elaborata con successo")
    String message;

    @Schema(description = "L'array di lezioni dell'utente")
    LessonResponseDTO[] lessons;

    public LessonsListDTO() {}

    public LessonsListDTO(String message, LessonResponseDTO[] lessons) {
        this.message = message;
        this.lessons = lessons;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LessonResponseDTO[] getLessons() {
        return lessons;
    }

    public void setLessons(LessonResponseDTO[] lessons) {
        this.lessons = lessons;
    }

}
