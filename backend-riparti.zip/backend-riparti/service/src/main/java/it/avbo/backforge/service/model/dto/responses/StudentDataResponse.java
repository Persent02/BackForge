package it.avbo.backforge.service.model.dto.responses;

import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'oggetto JSON corrispondente alla risposta per l'api di invio dati utente nel caso di uno studente")
public class StudentDataResponse {

    @Schema(description = "Il messaggio della risposta")
    private String message;

    @Schema(description = "L'oggetto con i dati dello studente")
    private StudentDTO student;

    public StudentDataResponse() {}

    public StudentDataResponse(String message, StudentDTO student) {
        this.message = message;
        this.student = student;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public StudentDTO getStudent() {
        return student;
    }

    public void setStudent(StudentDTO student) {
        this.student = student;
    }
}
