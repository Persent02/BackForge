package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.Course;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class CourseDAOImplementation implements CourseDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    private EntityManager em;

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public Course getCourseById(int id) {

        return em.find(Course.class, id);
    }
    
    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Course> getCoursesByStudentEmail(String student_email) {

        TypedQuery<Course> query = em.createQuery(
                "SELECT c FROM Course c WHERE c.id IN (SELECT s.id.course_id FROM Subscription s WHERE s.id.student_email = :student_email)", Course.class
        );
        query.setParameter("student_email", student_email);
        return query.getResultList();
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<Course> getCoursesByTeacherEmail(String teacher_email) {

        TypedQuery<Course> query = em.createQuery(
                "SELECT c FROM Course c WHERE c.teacher_email = :teacher_email", Course.class
        );
        query.setParameter("teacher_email", teacher_email);
        return query.getResultList();
    }

    @Override
    @Transactional
    public void insertCourse(Course course) {
        em.persist(course);
    }

    @Override
    @Transactional
    public void activateCourse(int course_id) {

        em.createQuery("UPDATE Course c SET c.status = 'active' WHERE c.id = :course_id")
            .setParameter("course_id", course_id)
            .executeUpdate();

    }

    @Override
    @Transactional
    public void deleteCourseById(int courseId) {
        Course course = em.find(Course.class, courseId);
        if (course != null) {
            em.remove(em.contains(course) ? course : em.merge(course));
        }
    }
}
