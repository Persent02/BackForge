package it.avbo.backforge.service.model.dto.responses;

import it.avbo.backforge.service.model.jpa.Course;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta il JSON da inviare al client ")
public class CourseListDTO {

    @Schema(description = "Il messaggio di stato della richiesta", examples = "Richiesta elaborata con successo")
    private String message;

    @Schema(description = "La lista dei corsi trovati")
    private Course[] courses;

    public CourseListDTO() {}

    public CourseListDTO(Course[] courses) {
        this.courses = courses;
    }

    public CourseListDTO(String message, Course[] courses) {
        this.message = message;
        this.courses = courses;
    }

    public Course[] getCourses() {
        return courses;
    }

    public void setCourses(Course[] courses) {
        this.courses = courses;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}