package it.avbo.backforge.service.security;

import io.smallrye.jwt.build.Jwt;
import io.smallrye.jwt.build.JwtClaimsBuilder;
import io.smallrye.jwt.build.JwtSignatureException;
import jakarta.enterprise.context.ApplicationScoped;

import java.util.Optional;

@ApplicationScoped
public class JWTProvider {

    public static Optional<String> generateToken(String email, String role) {
        try {
            // creo un builder "vuoto"
            JwtClaimsBuilder builder = Jwt.claims();

            // aggiungo i claim (che mi servono)
            builder.issuer("riparti.avbolabs.eu");
            builder.subject(email);
            builder.groups(role);
            builder.expiresIn(604800); //una settimana

            // Firma con la chiave definita in mp.jwt.sign.key-location
            return Optional.of(builder.sign());
        } catch (JwtSignatureException e) {
            return Optional.empty();
        }
    }
}