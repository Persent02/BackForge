package it.avbo.backforge.service.utility;

public class Formatter {

    public static String[] getNameAndSurnameFromEmail(String email) {

        String[] name_surname = new String[2];
        name_surname[0] = email.split("@")[0].split("\\.")[0];
        name_surname[1] = email.split("@")[0].split("\\.")[1];

        return name_surname;
    }
}
