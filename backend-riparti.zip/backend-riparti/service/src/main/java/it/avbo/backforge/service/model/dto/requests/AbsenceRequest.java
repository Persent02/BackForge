package it.avbo.backforge.service.model.dto.requests;

public class AbsenceRequest {
    private int lesson_id;
    private String cause;

    public AbsenceRequest() {}

    public AbsenceRequest(int lesson_id, String cause) {
        this.lesson_id = lesson_id;
        this.cause = cause;
    }

    public int getLesson_id() {
        return lesson_id;
    }

    public void setLesson_id(int lesson_id) {
        this.lesson_id = lesson_id;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }
}