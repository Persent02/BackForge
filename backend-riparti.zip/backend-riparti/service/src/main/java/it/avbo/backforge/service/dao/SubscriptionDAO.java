package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.SubscriptionId;
import jakarta.ejb.Local;

import it.avbo.backforge.service.model.jpa.Subscription;
import java.util.List;

@Local
public interface SubscriptionDAO {

    List<String> getSubscribedByCourse(int course_id);
    void save(Subscription subscription);
    void deleteByCourseId(int course_id);
    List<SubscriptionId> findByCourseId(int course_id);
    void deleteByStudentAndCourse(String email, int courseId);
}
