package it.avbo.backforge.service.model.jpa;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.security.SecureRandom;
import java.sql.Date;
import java.time.LocalTime;

@Entity
@Table(name = "Lesson")
public class Lesson {

    @Id
    private int id;

    private Date date;
    private LocalTime start_time;
    private LocalTime end_time;
    private int course_id;

    public Lesson() {}

    public Lesson(Date date, int course_id, int start_hour, int start_minute, int end_hour, int end_minute) {
        this.date = date;
        this.course_id = course_id;
        start_time = LocalTime.of(start_hour, start_minute);
        end_time = LocalTime.of(end_hour, end_minute);

        SecureRandom random = new SecureRandom();
        this.id = random.nextInt(100000);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStart_time() {
        return start_time.toString();
    }

    public void setStart_time(int hour, int minute) {
        this.start_time = LocalTime.of(hour, minute);
    }

    public String getEnd_time() {
        return end_time.toString();
    }

    public void setEnd_time(int hour, int minute) {
        this.end_time = LocalTime.of(hour, minute);
    }

    public int getCourse_id() {
        return course_id;
    }

    public void setCourse_id(int course_id) {
        this.course_id = course_id;
    }
}
