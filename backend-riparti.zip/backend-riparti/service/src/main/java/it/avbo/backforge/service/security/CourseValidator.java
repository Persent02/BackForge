package it.avbo.backforge.service.security;

import it.avbo.backforge.service.exceptions.DataNotValidException;
import it.avbo.backforge.service.model.dto.requests.CourseInputDataDTO;
import it.avbo.backforge.service.model.dto.requests.LessonRequiredDataDTO;
import it.avbo.backforge.service.utility.DateConverter;

import java.util.Objects;

public class CourseValidator {

    public static void validateCourseInputData(CourseInputDataDTO course) throws DataNotValidException {

        validateTitle(course.getTitle());

        validateSubject(course.getSubject());

        validateParticipantsNumbers(course.getMin_participants(), course.getMax_participants());

        validateDescription(course.getDescription());

        validateType(course.getType());

        validateCourseYears(course.getYears());

        validateCourseSpecializations(course.getSpecializations());

        validateLessons(course.getLessons());
    }

    public static void validateLessons(LessonRequiredDataDTO[] lessons) throws DataNotValidException {
        //controllo array lezioni
        if (lessons.length == 0) {
            throw new DataNotValidException("Lezioni del corso non valide");
        }

        for (LessonRequiredDataDTO lesson : lessons) {

            if (lesson.getDate() == null || lesson.getDate().isEmpty()) {
                throw new DataNotValidException("Una lezione ha la data non specificata");
            }

            if (!lesson.getDate().matches("\\d{4}-\\d{2}-\\d{2}")) {
                throw new DataNotValidException("Data lezione non nel formato valido");
            }

            if (lesson.getStart_time().isEmpty()) {
                throw new DataNotValidException("Una lezione ha la l'ora di inizio non specificata");
            }

            if (lesson.getEnd_time().isEmpty()) {
                throw new DataNotValidException("Una lezione ha l'ora di fine non specificata");
            }

            if (!lesson.getStart_time().matches("\\d{2}:\\d{2}:\\d{2}")) {
                throw new DataNotValidException("Ora inizio lezione non nel formato valido");
            }

            if (!lesson.getEnd_time().matches("\\d{2}:\\d{2}:\\d{2}")) {
                throw new DataNotValidException("Ora fine lezione non nel formato valido");
            }

            int[] start_time = DateConverter.covertTimeToIntArray(lesson.getStart_time());
            int[] end_time = DateConverter.covertTimeToIntArray(lesson.getEnd_time());
            if (DateConverter.convertStandardTimeToMinutes(start_time) > DateConverter.convertStandardTimeToMinutes(end_time)) {
                throw new DataNotValidException("Una lezione ha l'ora di fine più bassa dell'ora di inizio");
            }
        }
    }

    public static void validateCourseSpecializations(String[] specializations) throws DataNotValidException {
        //controllo array indirizzi
        if (specializations.length == 0) {
            throw new DataNotValidException("Indirizzi del corso non validi");
        }
    }

    public static void validateCourseYears(String[] years) throws DataNotValidException {
        //controlli array anni
        if (years.length == 0 || years.length > 5) {
            throw new DataNotValidException("Anni del corso non validi");
        }
    }

    public static void validateDescription(String description) throws DataNotValidException {
        //controlli descrizione
        if (description == null || description.isEmpty()) {
            throw new DataNotValidException("La descrizione del corso deve essere specificata");
        }
    }

    public static void validateType(String type) throws DataNotValidException {
        //controlli tipo del corso
        if (type == null || type.isEmpty()) {
            throw new DataNotValidException("Il tipo del corso deve essere specificato");
        }

        if (!Objects.equals(type, "Recupero") && !Objects.equals(type, "Potenziamento")) {
            throw new DataNotValidException("Il tipo del corso non è ne recupero ne potenziamento");
        }
    }

    public static void validateParticipantsNumbers(int min_number, int max_number) throws DataNotValidException {
        //controlli numeri partecipanti
        if (min_number < 0 || max_number < 0) {
            throw new DataNotValidException("Il numero di partecipanti è negativo");
        }

        if (max_number < min_number) {
            throw new DataNotValidException("I numeri di partecipanti non sono inseriti logicamente");
        }
    }

    public static void validateSubject(String subject) throws DataNotValidException {
        //controlli campo subject
        if (subject == null || subject.isEmpty()) {
            throw new DataNotValidException("La materia del corso deve essere specificata");
        }

        if (subject.length() > 100) {
            throw new DataNotValidException("La materia del corso supera i 100 caratteri");
        }
    }

    public static void validateTitle(String title) throws DataNotValidException {
        //controlli campo title
        if (title == null || title.isEmpty()) {
            throw new DataNotValidException("Il titolo del corso deve essere specificato");
        }

        if (title.length() > 150) {
            throw new DataNotValidException("Il titolo del corso supera i 150 caratteri");
        }
    }

    public static void validateId(int id) throws DataNotValidException {
        if (id < 0 || id > 99999) {
            throw new DataNotValidException("id non valido");
        }
    }
}
