package it.avbo.backforge.service.dao;

import it.avbo.backforge.service.model.jpa.CourseYears;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import java.util.List;

@ApplicationScoped
public class CourseYearsDAOImplementation implements CourseYearsDAO {

    @PersistenceContext(unitName = "db-management-PU", type = PersistenceContextType.TRANSACTION, synchronization = SynchronizationType.SYNCHRONIZED)
    private EntityManager em;

    @Override
    @Transactional
    public void insertYear(CourseYears courseYears) {
        em.persist(courseYears);
    }

    @Override
    @Transactional
    public void deleteYear(CourseYears courseYears) {
        em.remove(em.contains(courseYears) ? courseYears : em.merge(courseYears));
    }

    @Override
    @Transactional(Transactional.TxType.SUPPORTS)
    public List<String> getYearsByCourseId(int course_id) {

        TypedQuery<String> query = em.createQuery(
                "SELECT cy.id.year FROM CourseYears cy WHERE cy.id.course_id = :course_id", String.class
        );
        query.setParameter("course_id", course_id);
        return query.getResultList();
    }
}
