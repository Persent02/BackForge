package it.avbo.backforge.service.view;


import it.avbo.backforge.service.exceptions.ResourceNotFoundException;
import it.avbo.backforge.service.model.dto.responses.*;
import it.avbo.backforge.service.control.UserService;
import jakarta.annotation.security.DenyAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;

@Path("/user")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class UserResource {

    @Inject
    private UserService userService;

    @GET
    @Operation(summary = "Recupera i dati di un utente")
    @RolesAllowed({"student", "teacher"})
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Dati insegnante recuperati correttamente",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "404",
                    description = "Insegnante non trovato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response getUserData(@Context SecurityContext ctx) {

        TeacherDTO teacherDTO = new TeacherDTO();
        StudentDTO studentDTO = new StudentDTO();

        String email = ctx.getUserPrincipal().getName();
        try {
            if (email.endsWith("@avbo.it")) {
                teacherDTO = userService.getTeacherData(email);

            } else if (email.endsWith("@aldini.istruzioneer.it")) {
                studentDTO = userService.getStudentData(email);
            }

        } catch (ResourceNotFoundException e) {
            return Response.status(404)
                    .entity(new BasicResponseDTO("Utente non trovato"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            // Gestione errore generico
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        if (email.endsWith("@avbo.it")) {
            return Response.status(200)
                    .entity(new TeacherDataResponse("Richiesta elaborata con successo", teacherDTO))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(200)
                .entity(new StudentDataResponse("Richiesta elaborata con successo", studentDTO))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }
}