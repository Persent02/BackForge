package it.avbo.backforge.service.view;

import it.avbo.backforge.service.control.CourseService;
import it.avbo.backforge.service.control.SubscriptionService;
import it.avbo.backforge.service.exceptions.DataNotValidException;
import it.avbo.backforge.service.exceptions.ResourceNotFoundException;
import it.avbo.backforge.service.model.dto.responses.CourseListDTO;
import it.avbo.backforge.service.model.dto.requests.CourseInputDataDTO;
import it.avbo.backforge.service.model.dto.responses.BasicResponseDTO;
import it.avbo.backforge.service.model.dto.SingleCourseDTO;
import it.avbo.backforge.service.model.dto.responses.SingleCourseResponse;
import jakarta.annotation.security.DenyAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;

@Path("/course")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@DenyAll
public class CourseResource {

    @Inject
    private CourseService courseService;

    @Inject
    private SubscriptionService subscriptionService;

    @GET
    @Path("/list")
    @RolesAllowed({"student", "teacher"})
    @Operation(summary = "Gestisce l'invio della lista di corsi in base al ruolo dell'utente (studente o docente)")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Lista corsi inviata",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response getCourseList(@Context SecurityContext ctx) {

        //dal jwt si ricava l'email dell'utente
        String email = ctx.getUserPrincipal().getName();
        CourseListDTO course_list;

        try {
            course_list = courseService.getCoursesList(email);
        } catch (DataNotValidException e) {
            return Response.status(422)
                    .entity(new BasicResponseDTO(e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(200)
                .entity(course_list)
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

    @POST
    @Path("/create")
    @RolesAllowed("teacher")
    @Operation(summary = "Gestisce la creazione di un nuovo corso")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "201",
                    description = "Corso creato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "403",
                    description = "Utente non autorizzato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "422",
                    description = "Dati inseriti non validi",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response createCourse(
            @RequestBody(
                    description = "Dati del corso da creare",
                    content = @Content(schema = @Schema(implementation = CourseInputDataDTO.class))
            )
            CourseInputDataDTO input_data, @Context SecurityContext ctx
    ) {
        try {
            courseService.createCourse(input_data, ctx.getUserPrincipal().getName());
        } catch (DataNotValidException e) {
            return Response.status(422)
                    .entity(new BasicResponseDTO("Dati del corso non validi " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.ok()
                .entity(new BasicResponseDTO("Corso creato"))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

    @GET
    @Path("/{id_corso}")
    @DenyAll
    @RolesAllowed({"student", "teacher"})
    @Operation(summary = "Gestisce l'invio di tutti i dati di un corso")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Dati corso inviati",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "422",
                    description = "Id del corso non valido",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response getCourse(@PathParam("id_corso") int id_corso) {

        SingleCourseDTO course_data;
        try {
            course_data = courseService.getCourseData(id_corso);
        } catch (DataNotValidException e) {
            return Response.status(422)
                    .entity(new BasicResponseDTO("Id del corso non valido"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        }

        SingleCourseResponse response = new SingleCourseResponse();
        response.setMessage("Richiesta elaborata con successo");
        response.setCourse(course_data);
        return Response.ok()
                .entity(response)
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

    @POST
    @Path("/subscribe/{id_corso}")
    @DenyAll
    @RolesAllowed("student")
    @Operation(summary = "Gestisce l'iscrizione ad un corso")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "201",
                    description = "Iscrizione effettuata",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "403",
                    description = "Utente non autorizzato ad attivare il corso",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "404",
                    description = "Corso non trovato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response subscribeStudentToCourse(@PathParam("id_corso") int id_corso, @Context SecurityContext ctx) {
        try {
            subscriptionService.subscribeToCourse(id_corso, ctx.getUserPrincipal().getName());
        } catch (ResourceNotFoundException e) {
            return Response.status(404)
                    .entity(new BasicResponseDTO("Corso non trovato"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();

        }

        return Response.status(201)
                .entity(new BasicResponseDTO("Iscrizione effettuata"))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }
    @POST
    @Path("/activate/{id_corso}")
    @DenyAll
    @RolesAllowed("teacher")
    @Operation(summary = "Gestisce l'attivazione di un corso")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Corso attivato con successo",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "403",
                    description = "Utente non autorizzato ad attivare il corso",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "404",
                    description = "Corso non trovato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response activateCourse(@PathParam("id_corso") int id_corso) {

        try {
            courseService.activateCourse(id_corso);
        } catch (NotFoundException e) {
            return Response.status(404)
                    .entity(new BasicResponseDTO("Corso non trovato"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione: " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(200)
                .entity(new BasicResponseDTO("Corso attivato con successo"))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }
    @POST
    @Path("/unsubscribe/{id_corso}")
    @DenyAll
    @RolesAllowed("student")
    @Operation(summary = "Gestisce la disiscrizione di un utente da un corso")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Disiscrizione effettuata con successo",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "403",
                    description = "Utente non autorizzato ad attivare il corso",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "404",
                    description = "Corso non trovato o utente non iscritto",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response unsubscribeStudentFromCourse(@PathParam("id_corso") int id_corso, @Context SecurityContext ctx) {

        try {
            subscriptionService.unsubscribeFromCourse(id_corso, ctx.getUserPrincipal().getName());

        } catch (NotFoundException e) {
            return Response.status(404)
                    .entity(new BasicResponseDTO("Corso non trovato o utente non iscritto"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione: " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(200)
                .entity(new BasicResponseDTO("Disiscrizione effettuata con successo"))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

    @DELETE
    @Path("/delete/{id_corso}")
    @DenyAll
    @RolesAllowed("teacher")
    @Operation(summary = "Gestisce l'eliminazione di un corso")
    @APIResponses(value = {
            @APIResponse(
                    responseCode = "200",
                    description = "Corso eliminato con successo",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "401",
                    description = "Utente non autenticato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "403",
                    description = "Utente non autorizzato ad eliminare il corso",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "404",
                    description = "Corso non trovato",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            ),
            @APIResponse(
                    responseCode = "500",
                    description = "Errore durante l'elaborazione",
                    content = @Content(mediaType = MediaType.APPLICATION_JSON)
            )
    })
    public Response deleteCourse(@PathParam("id_corso") int id_corso) {

        try {
            courseService.deleteCourse(id_corso);

        } catch (NotFoundException e) {
            return Response.status(404)
                    .entity(new BasicResponseDTO("Corso non trovato"))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        } catch (Exception e) {
            return Response.status(500)
                    .entity(new BasicResponseDTO("Errore durante l'elaborazione: " + e.getMessage()))
                    .header("Access-Control-Allow-Origin", "*")
                    .build();
        }

        return Response.status(200)
                .entity(new BasicResponseDTO("Corso eliminato con successo"))
                .header("Access-Control-Allow-Origin", "*")
                .build();
    }

}
