package it.avbo.backforge.service.model.dto;

import it.avbo.backforge.service.model.dto.responses.SimpleLessonDTO;
import org.eclipse.microprofile.openapi.annotations.media.Schema;

@Schema(description = "Rappresenta l'oggetto contenente le informazioni di un singolo corso")
public class SingleCourseDTO {

    @Schema(description = "L'id del corso", examples = "25")
    private int id;

    @Schema(description = "Il titolo del corso", examples = "Programmazione in Java")
    private String title;

    @Schema(description = "Il tipo di corso (recupero o potenziamento)", examples = "Potenziamento")
    private String type;

    @Schema(description = "La materia del corso", examples = "Informatica")
    private String subject;

    @Schema(description = "Lo stato del corso", examples = "active")
    private String status;

    @Schema(description = "La descrizione del corso", examples = "Corso di potenziamento per aumentare le proprie conoscenze sulla OOP")
    private String desc;

    @Schema(description = "Il numero minimo di partecipanti per il corso", examples = "10")
    private int min_participants;

    @Schema(description = "Il numero massimo di partecipanti per il corso", examples = "21")
    private int max_participants;

    @Schema(description = "Il numero corrente di partecipanti per il corso", examples = "18")
    private int num_participants;

    @Schema(description = "L'email del professore che ha creato il corso", examples = "elisa.turrini@avbo.it")
    private String creator_email;

    @Schema(description = "L'array degli anni i cui studenti sono accettati a frequentare il corso", examples = {"quarta", "quinta"})
    private String[] years;

    @Schema(description = "L'array delle specializzazioni i cui studenti sono accettati a frequentare il corso", examples = {"quarta", "quinta"})
    private String[] specializations;

    @Schema(description = "L'array delle email dei partecipanti del corso", examples = {"francesco.sorghi@aldini.istruzioneer.it", "lorenzo.diduca@aldini.istruzioneer.it"})
    private String[] participants;

    @Schema(description = "L'array delle lezioni del corso")
    private SimpleLessonDTO[] lessons;

    public SingleCourseDTO() {}

    public SingleCourseDTO(int id, String title, String type, String subject, String desc, int min_participants, int max_participants, int num_participants, String creator_email, String[] years, String[] specializations, String[] participants, SimpleLessonDTO[] lessons, String status) {
        this.id = id;
        this.title = title;
        this.type = type;
        this.subject = subject;
        this.desc = desc;
        this.min_participants = min_participants;
        this.max_participants = max_participants;
        this.num_participants = num_participants;
        this.creator_email = creator_email;
        this.years = years;
        this.specializations = specializations;
        this.participants = participants;
        this.lessons = lessons;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getMin_participants() {
        return min_participants;
    }

    public void setMin_participants(int min_participants) {
        this.min_participants = min_participants;
    }

    public int getMax_participants() {
        return max_participants;
    }

    public void setMax_participants(int max_participants) {
        this.max_participants = max_participants;
    }

    public int getNum_participants() {
        return num_participants;
    }

    public void setNum_participants(int num_participants) {
        this.num_participants = num_participants;
    }

    public String getCreator_email() {
        return creator_email;
    }

    public void setCreator_email(String creator_email) {
        this.creator_email = creator_email;
    }

    public String[] getYears() {
        return years;
    }

    public void setYears(String[] years) {
        this.years = years;
    }

    public String[] getSpecializations() {
        return specializations;
    }

    public void setSpecializations(String[] specializations) {
        this.specializations = specializations;
    }

    public String[] getParticipants() {
        return participants;
    }

    public void setParticipants(String[] participants) {
        this.participants = participants;
    }

    public SimpleLessonDTO[] getLessons() {
        return lessons;
    }

    public void setLessons(SimpleLessonDTO[] lessons) {
        this.lessons = lessons;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
