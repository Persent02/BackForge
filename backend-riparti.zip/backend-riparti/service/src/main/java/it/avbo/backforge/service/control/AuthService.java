package it.avbo.backforge.service.control;

import it.avbo.backforge.service.dao.UserDAO;
import it.avbo.backforge.service.dao.SubjectDAO;
import it.avbo.backforge.service.exceptions.*;
import it.avbo.backforge.service.model.dto.requests.LoginRequest;
import it.avbo.backforge.service.model.dto.requests.RegistrationRequest;
import it.avbo.backforge.service.model.jpa.Student;
import it.avbo.backforge.service.model.jpa.Subject;
import it.avbo.backforge.service.model.jpa.SubjectId;
import it.avbo.backforge.service.model.jpa.Teacher;
import it.avbo.backforge.service.security.JWTProvider;
import it.avbo.backforge.service.security.PasswordEncoder;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.Arrays;
import java.util.Optional;

import static it.avbo.backforge.service.security.PasswordEncoder.hashPassword;
import static it.avbo.backforge.service.security.UserValidator.validateLoginData;
import static it.avbo.backforge.service.security.UserValidator.validateRegistrationData;

@ApplicationScoped
public class AuthService {
    
    @Inject //iniezione per fare in modo che si attacchi al DB
    private UserDAO userDAO;
    
    @Inject //iniezione per fare in modo che si attacchi al DB
    private SubjectDAO subjectDAO;

    public void userRegistration(RegistrationRequest request) throws DataNotValidException, AlreadyRegisteredException, PasswordHashException {

        //controllo validità email con eccezione custom
        validateRegistrationData(request);

        //controllo presenza di un utente con quella mail già registrato, sia per lo studente che per il docente
        if (request.getEmail().endsWith("@avbo.it")) {

            Optional<Teacher> alreadyRegisteredTeacher = userDAO.getTeacherByEmail(request.getEmail());
            if (alreadyRegisteredTeacher.isPresent()) {
                throw new AlreadyRegisteredException("User already registered");
            } else {

                //Se l'email non è presente nel db si crea l'oggetto Teacher JPA e si inserisce nel db
                byte[] salt = PasswordEncoder.generateSalt();
                byte[] psw_hash;
                try {
                    psw_hash = hashPassword(request.getPassword().toCharArray(), salt);
                } catch (Exception e) {
                    throw new PasswordHashException("Error hashing password");
                }

                Teacher teacher = new Teacher(request.getEmail(), psw_hash, request.getName(), request.getSurname(), "T1", salt);
                userDAO.insertTeacher(teacher);

                //per ogni materia insegnata dallo studente si crea un oggetto Subject e si inserisce nel db
                String[] subjects = request.getSubjects();
                for (String s : subjects) {

                    SubjectId subjectId = new SubjectId(s, request.getEmail());
                    Subject subject = new Subject(subjectId);

                    subjectDAO.insertSubject(subject);
                }
            }

        } else if (request.getEmail().endsWith("@aldini.istruzioneer.it")) {
            Optional<Student> alreadyRegisteredStudent = userDAO.getStudentByEmail(request.getEmail());
            if (alreadyRegisteredStudent.isPresent()) {
                throw new AlreadyRegisteredException("User already registered");
            } else {

                //Se l'email non è presente nel db si crea l'oggetto Student JPA e si inserisce nel db
                byte[] salt = PasswordEncoder.generateSalt();
                byte[] psw_hash;
                try {
                    psw_hash = hashPassword(request.getPassword().toCharArray(), salt);
                } catch (Exception e) {
                    throw new PasswordHashException("Error hashing password");
                }

                Student student = new Student(request.getEmail(), psw_hash, request.getName(), request.getSurname(), "S1", request.getClass_name(), salt);
                userDAO.insertStudent(student);
            }
        }

    }

    public String userLogin(LoginRequest request) throws UserNotFoundException, PasswordHashException, WrongCredentialsException, TokenCreationException {

        //controllo validità dati richiesta
        validateLoginData(request);

        //se l'utente è un docente
        if (request.getEmail().endsWith("@avbo.it")) {

            //controlli che l'utente si sia registrato
            Optional<Teacher> registeredTeacher = userDAO.getTeacherByEmail(request.getEmail());
            if (registeredTeacher.isPresent()) {

                //si controlla la password facendone l'hash e poi comparandola con quella ricevuta dal db
                Teacher teacherData = registeredTeacher.get();
                checkPasswordMatch(teacherData.getSalt(), request.getPassword().toCharArray(), teacherData.getPassword());

                //si genera un JSON web token che rappresenta la sessione dell'utente
                Optional<String> token = JWTProvider.generateToken(request.getEmail(), "teacher");
                if (token.isPresent()) return token.get();
                else throw new TokenCreationException("Token creation failed");

            } else {
                throw new UserNotFoundException("User not found");
            }

        } else if (request.getEmail().endsWith("@aldini.istruzioneer.it")) {

            //controlli che l'utente si sia registrato
            Optional<Student> registeredStudent = userDAO.getStudentByEmail(request.getEmail());
            if (registeredStudent.isPresent()) {

                //si controlla la password facendone l'hash e poi comparandola con quella ricevuta dal db
                Student studentData = registeredStudent.get();
                checkPasswordMatch(studentData.getSalt(), request.getPassword().toCharArray(), studentData.getPassword());

                //si genera un JSON web token che rappresenta la sessione dell'utente
                Optional<String> token = JWTProvider.generateToken(request.getEmail(), "student");
                if (token.isPresent()) return token.get();
                else throw new TokenCreationException("Token creation failed");

            } else {
                throw new UserNotFoundException("User not found");
            }
        }

        return "";
    }

    private void checkPasswordMatch(byte[] salt, char[] request_password, byte[] registered_password) throws PasswordHashException, WrongCredentialsException {
        byte[] requestPwsHash;

        try {
            requestPwsHash = hashPassword(request_password, salt);
        } catch (Exception e) {
            throw new PasswordHashException("Error hashing password");
        }

        if (!Arrays.equals(requestPwsHash, registered_password)) {
            throw new WrongCredentialsException("Password does not match");
        }
    }
}
